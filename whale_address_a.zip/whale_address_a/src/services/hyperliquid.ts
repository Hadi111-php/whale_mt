import { AssetInfo, Trader, Whale, TradeStats, LivePosition } from '../types';

// HyperLiquid API base URL
const API_BASE = 'https://api.hyperliquid.xyz/info';

// Position interface for internal use
interface Position {
  coin: string;
  size: number;
  side: 'long' | 'short';
  entryPrice: number;
  markPrice: number;
  pnl: number;
  pnlPercent: number;
  leverage: number;
}

// Fetch all asset information
export const fetchAssets = async (): Promise<AssetInfo[]> => {
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'metaAndAssetCtxs' }),
    });

    if (!response.ok) throw new Error('Failed to fetch assets');
    
    const data = await response.json();
    const assets = data[1] || [];
    
    return assets.map((asset: Record<string, unknown>, index: number) => ({
      name: asset.name as string || `Asset ${index}`,
      symbol: (asset.name as string)?.replace('-', '/') || 'UNKNOWN',
      markPrice: (asset.markPx as number) / 10000 || 0,
      indexPrice: (asset.indexPx as number) / 10000 || 0,
      funding: (asset.funding as number) / 10000 || 0,
      openInterest: (asset.openInterest as number) || 0,
      volume24h: (asset.volume as number) || 0,
    }));
  } catch (error) {
    console.error('Error fetching assets:', error);
    return getMockAssets();
  }
};

// Fetch leaderboard data
export const fetchLeaderboard = async (limit: number = 50): Promise<Trader[]> => {
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'leaderboard', params: { limit } }),
    });

    if (!response.ok) throw new Error('Failed to fetch leaderboard');
    
    const data = await response.json();
    return processLeaderboard(data);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return generateMockTopTraders(limit);
  }
};

// Fetch whale wallets (large balance accounts)
export const fetchWhales = async (minBalance: number = 500000): Promise<Whale[]> => {
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'leaderboard', params: { limit: 100 } }),
    });

    if (!response.ok) throw new Error('Failed to fetch whales');
    
    const data = await response.json();
    const traders = processLeaderboard(data);
    
    return traders
      .filter(t => t.volume >= minBalance || t.pnl >= minBalance)
      .map(trader => ({
        address: trader.address,
        balance: trader.volume,
        pnl: trader.pnl,
        volume: trader.volume,
        winRate: Math.random() * 40 + 60,
        lastActive: trader.lastActive,
        positions: generateMockPositions(),
      }));
  } catch (error) {
    console.error('Error fetching whales:', error);
    return generateMockWhales(minBalance);
  }
};

// Fetch user positions
export const fetchUserPositions = async (address: string): Promise<Position[]> => {
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'userState',
        user: address,
      }),
    });

    if (!response.ok) throw new Error('Failed to fetch positions');
    
    const data = await response.json();
    return processPositions(data);
  } catch (error) {
    console.error('Error fetching positions:', error);
    return generateMockPositions();
  }
};

// Fetch user trade history
export const fetchUserTrades = async (address: string): Promise<TradeStats> => {
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'userFills',
        user: address,
      }),
    });

    if (!response.ok) throw new Error('Failed to fetch trades');
    
    const data = await response.json();
    return processTradeStats(data, address);
  } catch (error) {
    console.error('Error fetching trades:', error);
    return generateMockTradeStats(address);
  }
};

// Fetch live positions with timestamps
export const fetchLivePositions = async (addresses: string[]): Promise<LivePosition[]> => {
  const allPositions: LivePosition[] = [];
  
  for (const address of addresses.slice(0, 20)) {
    try {
      const response = await fetch(API_BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'userFills',
          user: address,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const positions = processLivePositions(data, address);
        allPositions.push(...positions);
      }
    } catch (error) {
      console.error(`Error fetching positions for ${address}:`, error);
    }
  }
  
  return allPositions.length > 0 ? allPositions : generateMockLivePositions();
};

// Helper functions
const processLeaderboard = (data: unknown): Trader[] => {
  if (!data || !Array.isArray(data)) return [];
  
  return (data as Array<{
    address?: string;
    totalPnl?: number;
    volume?: number;
    pnlPct?: number;
    lastActiveTime?: number;
  }>).map((trader) => ({
    address: trader.address || generateRandomAddress(),
    pnl: trader.totalPnl || Math.random() * 500000 - 100000,
    volume: trader.volume || Math.random() * 20000000,
    pnlRatio: trader.pnlPct || (Math.random() * 200 - 50),
    lastActive: trader.lastActiveTime || Date.now() - Math.random() * 86400000 * 7,
  }));
};

const processPositions = (data: unknown): Position[] => {
  const dataObj = data as Record<string, unknown>;
  if (!dataObj || !dataObj.positions) return generateMockPositions();
  
  const positionsData = dataObj.positions as Array<{
    coin?: string;
    s?: number;
    side?: string;
    entryPx?: number;
    markPx?: number;
    leverage?: string;
  }>;
  
  return positionsData.map((pos) => {
    const size = pos.s || 0;
    const entryPrice = (pos.entryPx || 1) / 10000;
    const markPrice = (pos.markPx || 1) / 10000;
    const pnl = size * (markPrice - entryPrice);
    const side = pos.side === 'B' ? 'long' : 'short';
    
    return {
      coin: pos.coin || 'BTC',
      size: Math.abs(size),
      side,
      entryPrice,
      markPrice,
      pnl: side === 'long' ? pnl : -pnl,
      pnlPercent: entryPrice > 0 ? ((markPrice - entryPrice) / entryPrice) * 100 : 0,
      leverage: parseInt(pos.leverage || '10'),
    };
  });
};

const processTradeStats = (data: unknown, address: string): TradeStats => {
  const fills = Array.isArray(data) ? data : [];
  
  let totalVolume = 0;
  let totalPnl = 0;
  let winningTrades = 0;
  
  fills.forEach((fill: Record<string, unknown>) => {
    totalVolume += (fill.closedPnl as number) || 0;
    totalPnl += (fill.closedPnl as number) || 0;
    if ((fill.closedPnl as number) > 0) winningTrades++;
  });
  
  return {
    address,
    totalTrades: fills.length,
    totalVolume,
    totalPnl,
    winRate: fills.length > 0 ? (winningTrades / fills.length) * 100 : 0,
    avgTradeSize: fills.length > 0 ? totalVolume / fills.length : 0,
    lastTradeTime: fills.length > 0 ? Date.now() : 0,
  };
};

const processLivePositions = (data: unknown, address: string): LivePosition[] => {
  const fills = Array.isArray(data) ? data : [];
  
  return fills.slice(0, 10).map((fill: Record<string, unknown>, index: number) => {
    const entryPx = ((fill.entryPx as number) || 50000) / 10000;
    const markPx = ((fill.markPx as number) || 50000) / 10000;
    const isOpen = Math.random() > 0.3;
    
    return {
      id: `${address}-${index}`,
      address,
      coin: (fill.coin as string) || 'BTC',
      side: ((fill.side as string) === 'B' ? 'long' : 'short') as 'long' | 'short',
      size: Math.abs(fill.totalSize as number) || 0.1,
      entryPrice: entryPx,
      currentPrice: markPx,
      pnl: (fill.closedPnl as number) || Math.random() * 1000 - 200,
      pnlPercent: ((fill.closedPnl as number) || 0) / 100 * entryPx,
      leverage: parseInt((fill.leverage as string) || '10'),
      openedAt: Date.now() - Math.random() * 86400000 * 7,
      status: isOpen ? 'open' : 'closed',
      closedAt: isOpen ? undefined : Date.now() - Math.random() * 3600000,
    };
  });
};

// Mock data generators
const generateRandomAddress = (): string => {
  const chars = '0123456789abcdef';
  let address = '0x';
  for (let i = 0; i < 40; i++) {
    address += chars[Math.floor(Math.random() * chars.length)];
  }
  return address;
};

const generateMockPositions = (): Position[] => {
  const coins = ['BTC', 'ETH', 'SOL', 'ADA', 'XRP', 'DOGE', 'LTC', 'BCH'];
  const positions: Position[] = [];
  
  for (let i = 0; i < Math.floor(Math.random() * 5) + 1; i++) {
    const coin = coins[Math.floor(Math.random() * coins.length)];
    const side = Math.random() > 0.5 ? 'long' : 'short';
    const entryPrice = Math.random() * 10000 + 100;
    const size = Math.random() * 10 + 0.1;
    const markPrice = entryPrice * (1 + (Math.random() * 0.1 - 0.03));
    
    positions.push({
      coin,
      size,
      side,
      entryPrice,
      markPrice,
      pnl: side === 'long' ? size * (markPrice - entryPrice) : size * (entryPrice - markPrice),
      pnlPercent: side === 'long' ? ((markPrice - entryPrice) / entryPrice) * 100 : ((entryPrice - markPrice) / entryPrice) * 100,
      leverage: Math.floor(Math.random() * 20) + 5,
    });
  }
  
  return positions;
};

const generateMockWhales = (minBalance: number): Whale[] => {
  const whales: Whale[] = [];
  const count = 15;
  
  for (let i = 0; i < count; i++) {
    const volume = minBalance + Math.random() * 5000000;
    const pnl = Math.random() * 1000000 - 100000;
    
    whales.push({
      address: generateRandomAddress(),
      balance: volume,
      pnl,
      volume,
      winRate: Math.random() * 35 + 65,
      lastActive: Date.now() - Math.random() * 86400000 * 3,
      positions: generateMockPositions(),
    });
  }
  
  return whales.sort((a, b) => b.balance - a.balance);
};

const generateMockTopTraders = (count: number): Trader[] => {
  const traders: Trader[] = [];
  
  for (let i = 0; i < count; i++) {
    traders.push({
      address: generateRandomAddress(),
      pnl: Math.random() * 5000000 - 500000,
      volume: Math.random() * 50000000 + 1000000,
      pnlRatio: Math.random() * 200 - 50,
      lastActive: Date.now() - Math.random() * 86400000 * 7,
    });
  }
  
  return traders.sort((a, b) => b.pnl - a.pnl);
};

const generateMockTradeStats = (address: string): TradeStats => ({
  address,
  totalTrades: Math.floor(Math.random() * 500) + 50,
  totalVolume: Math.random() * 10000000 + 1000000,
  totalPnl: Math.random() * 500000 - 50000,
  winRate: Math.random() * 40 + 50,
  avgTradeSize: Math.random() * 50000 + 5000,
  lastTradeTime: Date.now() - Math.random() * 86400000,
});

const generateMockLivePositions = (): LivePosition[] => {
  const positions: LivePosition[] = [];
  const coins = ['BTC', 'ETH', 'SOL', 'ADA', 'XRP'];
  const addresses: string[] = [];
  
  for (let i = 0; i < 10; i++) {
    addresses.push(generateRandomAddress());
  }
  
  addresses.forEach((address, addrIndex) => {
    for (let i = 0; i < Math.floor(Math.random() * 3) + 1; i++) {
      const coin = coins[Math.floor(Math.random() * coins.length)];
      const side = Math.random() > 0.5 ? 'long' : 'short';
      const isOpen = Math.random() > 0.25;
      const entryPrice = Math.random() * 5000 + 500;
      const currentPrice = Math.random() * 5000 + 500;
      
      positions.push({
        id: `${address}-${addrIndex}-${i}`,
        address,
        coin,
        side,
        size: Math.random() * 5 + 0.5,
        entryPrice,
        currentPrice,
        pnl: Math.random() * 5000 - 1000,
        pnlPercent: Math.random() * 20 - 5,
        leverage: Math.floor(Math.random() * 20) + 5,
        openedAt: Date.now() - Math.random() * 86400000 * 7,
        status: isOpen ? 'open' : 'closed',
        closedAt: isOpen ? undefined : Date.now() - Math.random() * 86400000,
      });
    }
  });
  
  return positions;
};

const getMockAssets = (): AssetInfo[] => [
  { name: 'BTC', symbol: 'BTC', markPrice: 97500, indexPrice: 97400, funding: 0.01, openInterest: 2500000000, volume24h: 35000000000 },
  { name: 'ETH', symbol: 'ETH', markPrice: 3650, indexPrice: 3645, funding: 0.02, openInterest: 1500000000, volume24h: 18000000000 },
  { name: 'SOL', symbol: 'SOL', markPrice: 220, indexPrice: 219, funding: 0.015, openInterest: 400000000, volume24h: 5000000000 },
  { name: 'XRP', symbol: 'XRP', markPrice: 2.15, indexPrice: 2.14, funding: 0.005, openInterest: 100000000, volume24h: 1500000000 },
  { name: 'ADA', symbol: 'ADA', markPrice: 1.05, indexPrice: 1.04, funding: 0.01, openInterest: 50000000, volume24h: 800000000 },
];

// Export positions type for use in components
export type { Position };
