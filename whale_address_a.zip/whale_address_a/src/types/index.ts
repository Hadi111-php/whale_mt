export interface Trader {
  address: string;
  pnl: number;
  volume: number;
  pnlRatio: number;
  lastActive: number;
  realizedPnl?: number;
  unrealizedPnl?: number;
}

export interface Whale {
  address: string;
  balance: number;
  pnl: number;
  volume: number;
  winRate: number;
  lastActive: number;
  positions: Position[];
}

export interface Position {
  coin: string;
  size: number;
  side: 'long' | 'short';
  entryPrice: number;
  markPrice: number;
  pnl: number;
  pnlPercent: number;
  leverage: number;
  openedAt?: number;
}

export interface Trade {
  id: string;
  address: string;
  coin: string;
  side: 'long' | 'short';
  size: number;
  price: number;
  pnl: number;
  fee: number;
  timestamp: number;
  isOpen: boolean;
}

export interface TradeStats {
  address: string;
  totalTrades: number;
  totalVolume: number;
  totalPnl: number;
  winRate: number;
  avgTradeSize: number;
  lastTradeTime: number;
}

export interface LivePosition {
  id: string;
  address: string;
  coin: string;
  side: 'long' | 'short';
  size: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  leverage: number;
  openedAt: number;
  status: 'open' | 'closed';
  closedAt?: number;
}

export interface AssetInfo {
  name: string;
  symbol: string;
  markPrice: number;
  indexPrice: number;
  funding: number;
  openInterest: number;
  volume24h: number;
}

export interface WalletActivity {
  address: string;
  type: 'open' | 'close' | 'deposit' | 'withdraw';
  coin: string;
  size: number;
  price: number;
  pnl?: number;
  timestamp: number;
}
